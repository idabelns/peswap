(this["webpackJsonpapeswap-frontend"]=this["webpackJsonpapeswap-frontend"]||[]).push([[22],
    
    {
        1088: function(n, t, e) {
            "use strict";
            e.r(t);
            var r, c = e(58),
                i = (e(0), e(4)),
                a = e(23),
                s = e(206),
                u = e(781),
                o = e(7),
                f = i.e.div(r || (r = Object(c.a)(["\n  align-items: center;\n  display: flex;\n  flex-direction: column;\n  height: calc(100vh - 64px);\n  justify-content: center;\n"])));
            t.default = function() {
                var n = Object(u.a)();
                return Object(o.jsx)(s.a, {
                    children: Object(o.jsxs)(f, {
                        // children: [Object(o.jsx)(a.O, {
                        //     width: "64px",
                        //     mb: "8px"
                        // }), Object(o.jsx)(a.G, {
                        //     size: "xxl",
                        //     children: "404"
                        // }), Object(o.jsx)(a.db, {
                        //     mb: "16px",
                        //     children: n(999, "Oops, page not found.")
                        // }), Object(o.jsx)(a.l, {
                        //     as: "a",
                        //     href: "/",
                        //     size: "sm",
                        //     children: n(999, "Back Home")
                        // })]
                    })
                })
            }
        },
        781: function(n, t, e) {
            "use strict";
            var r = e(0),
                c = e(207),
                i = e(790);
            t.a = function() {
                var n = Object(r.useContext)(c.a).translations;
                return function(t, e) {
                    return "error" === n[0] ? e : n.length > 0 ? Object(i.b)(n, t, e) : e
                }
            }
        },
        790: function(n, t, e) {
            "use strict";
            e.d(t, "b", (function() {
                return a
            })), e.d(t, "a", (function() {
                return s
            }));
            var r = e(0),
                c = e(207),
                i = /%(.*?)%/,
                a = function(n, t, e) {
                    var r = n.find((function(n) {
                        return n.data.stringId === t
                    }));
                    if (r) {
                        var c = r.data.text;
                        return c.includes("%") ? function(n, t) {
                            var e = i.exec(n)[0],
                                r = t.split(" ")[0];
                            return n.replace(e, r)
                        }(c, e) : c
                    }
                    return e
                },
                s = function(n, t) {
                    var e = Object(r.useContext)(c.a).translations;
                    return "error" === e[0] ? t : e.length > 0 ? a(e, n, t) : t
                }
        }
    }

]);
//# sourceMappingURL=22.57a56eae.chunk.js.map