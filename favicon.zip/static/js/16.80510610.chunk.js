(this["webpackJsonpapeswap-frontend"] = this["webpackJsonpapeswap-frontend"] || []).push([
	[16], {
		1094: function(n, e, t) {
			"use strict";
			t.r(e), t.d(e, "default", (function() {
				return qe
			}));
			var r, i, a, c, o, s, u, p, d, l, b, f, j, x, h, m, O, g, w, v, k, y, S, z, A, Q, H, C, N, T, F, L, B, I, E, R, W, D, P, q, U, V, G, M, $, K, X = t(58),
				Y = t(0),
				J = t(4),
				_ = t(23),
				Z = t(206),
				nn = t(2),
				en = t.n(nn),
				tn = t(9),
				rn = t(27),
				an = t(796),
				cn = t(792),
				on = t(793),
				sn = t(43),
				un = t(781),
				pn = t(809),
				dn = t(11),
				ln = t(12),
				bn = t.n(ln),
				fn = t(38),
				jn = t(29),
				xn = t(86),
				hn = t(65),
				mn = t(47),
				On = function() {
					var n = Object(Y.useState)([]),
						e = Object(rn.a)(n, 2),
						t = e[0],
						r = e[1],
						i = Object(sn.c)().account,
						a = Object(mn.a)().fastRefresh;
					return Object(Y.useEffect)((function() {
						i && function() {
							var n = Object(tn.a)(en.a.mark((function n() {
								var e, t, a;
								return en.a.wrap((function(n) {
									for (;;) switch (n.prev = n.next) {
										case 0:
											return e = hn.a.map((function(n) {
												return {
													address: Object(jn.g)(),
													name: "pendingCake",
													params: [n.pid, i]
												}
											})), n.next = 3, Object(fn.a)(xn, e);
										case 3:
											t = n.sent, a = hn.a.map((function(n, e) {
												return Object(dn.a)(Object(dn.a)({}, n), {}, {
													balance: new bn.a(t[e])
												})
											})), r(a);
										case 6:
										case "end":
											return n.stop()
									}
								}), n)
							})));
							return function() {
								return n.apply(this, arguments)
							}
						}()()
					}), [i, a]), t
				},
				gn = t(126),
				wn = t(7),
				vn = function(n) {
					var e = Object(un.a)(),
						t = Object(gn.a)(),
						r = t.login,
						i = t.logout,
						a = Object(_.qb)(r, i).onPresentConnectModal;
					return Object(wn.jsx)(_.o, Object(dn.a)(Object(dn.a)({
						onClick: a
					}, n), {}, {
						children: e(292, "UNLOCK WALLET")
					}))
				},
				kn = function() {
					var n = Object(Y.useState)([]),
						e = Object(rn.a)(n, 2),
						t = e[0],
						r = e[1],
						i = Object(sn.c)().account,
						a = Object(mn.a)().fastRefresh;
					return Object(Y.useEffect)((function() {
						i && function() {
							var n = Object(tn.a)(en.a.mark((function n() {
								var e, t;
								return en.a.wrap((function(n) {
									for (;;) switch (n.prev = n.next) {
										case 0:
											return e = hn.a.map((function(n) {
												return {
													address: Object(jn.g)(),
													name: "pendingCake",
													params: [n.pid, i]
												}
											})), n.next = 3, Object(fn.a)(xn, e);
										case 3:
											t = n.sent, r(t);
										case 5:
										case "end":
											return n.stop()
									}
								}), n)
							})));
							return function() {
								return n.apply(this, arguments)
							}
						}()()
					}), [i, a]), t
				},
				yn = t(791),
				Sn = function() {
					var n = Object(un.a)(),
						e = Object(sn.c)().account,
						t = kn().reduce((function(n, e) {
							return n + new bn.a(e).div(new bn.a(10).pow(18)).toNumber()
						}), 0);
					return e ? Object(wn.jsx)(yn.a, {
						value: t,
						fontSize: "57px"
					}) : Object(wn.jsx)(_.db, {
						color: "textDisabled",
						style: {
							lineHeight: "60px"
						},
						children: n(298, "Locked")
					})
				},
				zn = t(22),
				An = t(41),
				Qn = t(105),
				Hn = function() {
					var n = Object(un.a)(),
						e = Object(sn.c)().account,
						t = Object(An.i)().pending,
						r = Object(mn.a)().slowRefresh,
						i = Object(zn.b)();
					return Object(Y.useEffect)((function() {
						e && i(Object(Qn.b)(e))
					}), [e, i, r]), e ? Object(wn.jsx)(yn.a, {
						decimals: 2,
						value: t,
						prefix: "~$",
						fontSize: "12px",
						color: "#38A611",
						text: "poppins",
						fontWeight: 700
					}) : Object(wn.jsx)(_.db, {
						color: "textDisabled",
						style: {
							lineHeight: "60px",
							fontWeight: 700
						},
						fontFamily: "poppins",
						children: n(298, "Locked")
					})
				},
				Cn = t(784),
				Nn = t(153),
				Tn = function() {
					var n = Object(un.a)(),
						e = Object(Nn.a)(Object(jn.a)()),
						t = Object(sn.c)().account,
						r = Object(An.l)().toNumber() * Object(Cn.a)(e);
					return t ? Object(wn.jsx)(yn.a, {
						decimals: 2,
						value: r,
						prefix: "~$",
						fontSize: "12px",
						color: "#38A611",
						text: "poppins",
						fontWeight: 700
					}) : Object(wn.jsx)(_.db, {
						color: "textDisabled",
						style: {
							lineHeight: "36px",
							fontWeight: 700
						},
						fontFamily: "poppins",
						children: n(298, "Locked")
					})
				},
				Fn = function() {
					var n = Object(un.a)(),
						e = Object(Nn.a)(Object(jn.a)());
					return Object(sn.c)().account ? Object(wn.jsx)(yn.a, {
						value: Object(Cn.a)(e),
						fontSize: "40px"
					}) : Object(wn.jsx)(_.db, {
						color: "textDisabled",
						style: {
							lineHeight: "36px"
						},
						fontFamily: "poppins",
						children: n(298, "Locked")
					})
				},
				Ln = Object(J.e)(_.t)(r || (r = Object(X.a)(["\n  background-color: #a16552 !important;\n  background: none;\n  position: relative;\n  text-align: center;\n  padding: 12px;\n  border-top-left-radius: 32px;\n  border-top-right-radius: 32px;\n  font-size: 30px;\n  line-height: 34px;\n  letter-spacing: 0.05em;\n"]))),
				Bn = Object(J.e)(_.q)(i || (i = Object(X.a)(["\n  background-repeat: no-repeat;\n  background-position: top right;\n  width: 100%;\n  min-height: 250px;\n  text-align: center;\n  overflow: visible;\n  margin-left: auto;\n  margin-right: auto;\n"]))),
				In = J.e.div(a || (a = Object(X.a)(["\n  margin-bottom: 16px;\n"]))),
				En = J.e.div(c || (c = Object(X.a)(["\n  display: flex;\n  justify-content: center;\n  align-items: center;\n"]))),
				Rn = J.e.div(o || (o = Object(X.a)(["\n  color: #ffb300;\n  font-size: 12px;\n  margin-left: 2px;\n"]))),
				Wn = J.e.div(s || (s = Object(X.a)(["\n  position: absolute;\n  bottom: 0px;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n  -ms-transform: translate(-50%, -50%);\n  transform: translate(-50%, -50%);\n"]))),
				Dn = Object(J.e)(_.db)(u || (u = Object(X.a)(["\n  margin-top: 10px;\n  font-size: 28px;\n\n  ", " {\n    flex-direction: row;\n    margin-top: 50px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.lg
				})),
				Pn = Object(J.e)(_.l)(p || (p = Object(X.a)(["\n  background: #ffb300;\n  border-radius: 10px;\n  border: 0px;\n  width: 220px;\n  height: 50px;\n"]))),
				qn = Object(J.e)(_.h)(d || (d = Object(X.a)(["\n  width: 90px;\n  position: absolute;\n  left: 0px;\n  top: -20px;\n  z-index: 100;\n  transform: rotate(100deg);\n  filter: drop-shadow(0px 4px 2px rgba(0, 0, 0, 0.25));\n"]))),
				Un = Object(J.e)(_.h)(l || (l = Object(X.a)(["\n  width: 70px;\n  position: absolute;\n  bottom: -20px;\n  left: 30px;\n  z-index: 100;\n  transform: rotate(10deg);\n  filter: drop-shadow(0px 4px 2px rgba(0, 0, 0, 0.25));\n"]))),
				Vn = Object(J.e)(_.i)(b || (b = Object(X.a)(["\n  width: 90px;\n  position: absolute;\n  right: -10px;\n  top: 15px;\n  z-index: 100;\n  filter: drop-shadow(0px 4px 2px rgba(0, 0, 0, 0.25));\n"]))),
				Gn = Object(J.e)(Rn)(f || (f = Object(X.a)(["\n  font-family: Poppins;\n  font-weight: 700;\n"]))),
				Mn = J.e.div(j || (j = Object(X.a)(["\n  padding-bottom: 50px;\n"]))),
				$n = function() {
					var n = Object(Y.useState)(!1),
						e = Object(rn.a)(n, 2),
						t = e[0],
						r = e[1],
						i = Object(Y.useRef)(null),
						a = Object(Y.useState)("rewardBanana"),
						c = Object(rn.a)(a, 2),
						o = c[0],
						s = c[1],
						u = Object(sn.c)().account,
						p = Object(un.a)(),
						d = On().filter((function(n) {
							return n.balance.toNumber() > 0
						})),
						l = Object(on.a)(i, Object(pn.a)(d.map((function(n) {
							return n.pid
						}))).onReward),
						b = Object(Y.useCallback)(Object(tn.a)(en.a.mark((function n() {
							var e;
							return en.a.wrap((function(n) {
								for (;;) switch (n.prev = n.next) {
									case 0:
										return r(!0), n.prev = 1, s("rewardBanana"), n.next = 5, l();
									case 5:
										n.next = 11;
										break;
									case 7:
										n.prev = 7, n.t0 = n.catch(1), s("error"), null === (e = i.current) || void 0 === e || e.rewardMe();
									case 11:
										return n.prev = 11, r(!1), n.finish(11);
									case 14:
									case "end":
										return n.stop()
								}
							}), n, null, [
								[1, 7, 11, 14]
							])
						}))), [l]);
					return Object(wn.jsxs)(Bn, {
						children: [Object(wn.jsxs)(Ln, {
							children: [Object(wn.jsx)(qn, {}), Object(wn.jsx)(Un, {}), Object(wn.jsx)(Vn, {}), Object(wn.jsxs)(_.G, {
								size: "lg",
								mb: "0px",
								color: "white",
								children: [p(542, "Farms &"), Object(wn.jsx)("br", {}), p(542, "Staking")]
							})]
						}), Object(wn.jsxs)(_.r, {
							children: [u ? Object(wn.jsxs)(Mn, {
								children: [Object(wn.jsxs)(In, {
									children: [Object(wn.jsx)(Sn, {}), Object(wn.jsxs)(En, {
										children: [Object(wn.jsx)(Hn, {}), Object(wn.jsx)(Gn, {
											children: p(544, " total harvest value")
										})]
									})]
								}), Object(wn.jsxs)(In, {
									children: [Object(wn.jsx)(Fn, {}), Object(wn.jsxs)(En, {
										children: [Object(wn.jsx)(Tn, {}), Object(wn.jsx)(Gn, {
											children: p(546, "in BANANA in Wallet")
										})]
									})]
								})]
							}) : Object(wn.jsx)(En, {
								children: Object(wn.jsx)(Dn, {
									children: "LOCKED"
								})
							}), Object(wn.jsx)(Wn, {
								children: u ? Object(wn.jsx)(an.a, {
									ref: i,
									type: "emoji",
									config: cn.a[o],
									children: Object(wn.jsx)(Pn, {
										id: "harvest-all",
										disabled: d.length <= 0 || t,
										onClick: b,
										fullWidth: !0,
										children: t ? p(548, "COLLECTING BANANA") : p(999, "HARVEST ALL (".concat(d.length, ")"))
									})
								}) : Object(wn.jsx)(vn, {
									fullWidth: !0
								})
							})]
						})]
					})
				},
				Kn = t(75),
				Xn = t(88),
				Yn = Object(J.e)(_.q)(x || (x = Object(X.a)(["\n  width: 100%;\n  min-height: 376px;\n"]))),
				Jn = J.e.div(h || (h = Object(X.a)(["\n  align-items: center;\n  display: flex;\n  font-size: 14px;\n  justify-content: space-between;\n  padding-bottom: 4px;\n  padding-top: 4px;\n  padding-left: 12px;\n  padding-right: 10px;\n\n  ", " {\n    padding-left: 12px;\n    padding-right: 10px;\n  }\n\n  ", " {\n    padding-left: 6px;\n    padding-right: 6px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.lg
				}), (function(n) {
					return n.theme.mediaQueries.xl
				})),
				_n = J.e.div(m || (m = Object(X.a)(["\n  align-items: center;\n  display: flex;\n  font-size: 14px;\n  justify-content: space-between;\n  padding-bottom: 4px;\n  padding-top: 4px;\n  background: rgb(196, 196, 196, 0.2);\n  border-radius: 10px;\n  padding-left: 12px;\n  padding-right: 10px;\n\n  ", " {\n    padding-left: 12px;\n    padding-right: 10px;\n  }\n\n  ", " {\n    padding-left: 6px;\n    padding-right: 6px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.lg
				}), (function(n) {
					return n.theme.mediaQueries.xl
				})),
				Zn = Object(J.e)(_.r)(O || (O = Object(X.a)(["\n  padding-left: 20px;\n  padding-right: 20px;\n\n  ", " {\n    padding-left: 10px;\n    padding-right: 10px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.xl
				})),
				ne = Object(J.e)(_.db)(g || (g = Object(X.a)(["\n  font-weight: 400;\n  margin-right: 10px;\n"]))),
				ee = J.e.a(w || (w = Object(X.a)(["\n  background: #ffb300;\n  border-radius: 10px;\n  border: 0px;\n  position: absolute;\n  bottom: 0px;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  color: #ffffff;\n  box-shadow: inset 0px -1px 0px rgb(14 14 44 / 40%);\n  text-align: center;\n  width: 220px;\n  height: 50px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n"]))),
				te = function() {
					var n = Object(un.a)(),
						e = Object(Nn.d)(),
						t = Object(Xn.f)(),
						r = Object(An.l)(),
						i = Object(Nn.c)(Object(jn.a)()),
						a = e ? Object(Cn.a)(e) - Object(Cn.a)(i) : 0,
						c = Kn.a.toNumber(),
						o = r.toNumber() * a;
					return Object(wn.jsxs)(Yn, {
						children: [Object(wn.jsxs)(Zn, {
							children: [Object(wn.jsx)(_.G, {
								size: "lg",
								mb: "24px",
								textAlign: "center",
								children: n(534, "Banana Stats")
							}), Object(wn.jsxs)(_n, {
								children: [Object(wn.jsx)(ne, {
									fontSize: "14px",
									fontFamily: "poppins",
									children: n(536, "USD MARKET CAP")
								}), o && Object(wn.jsx)(yn.a, {
									fontSize: "14px",
									value: o,
									decimals: 0,
									prefix: "$",
									text: "poppins",
									fontWeight: 700
								})]
							}), Object(wn.jsxs)(Jn, {
								children: [Object(wn.jsx)(ne, {
									fontSize: "14px",
									fontFamily: "poppins",
									children: n(536, "BANANA IN CIRCULATION")
								}), a && Object(wn.jsx)(yn.a, {
									fontSize: "14px",
									value: a,
									text: "poppins",
									fontWeight: 700
								})]
							}), Object(wn.jsxs)(_n, {
								children: [Object(wn.jsx)(ne, {
									fontSize: "14px",
									fontFamily: "poppins",
									children: n(538, "BANANA BURNED")
								}), Object(wn.jsx)(yn.a, {
									fontSize: "14px",
									decimals: 0,
									value: Object(Cn.a)(i),
									text: "poppins",
									fontWeight: 700
								})]
							}), Object(wn.jsxs)(Jn, {
								children: [Object(wn.jsx)(ne, {
									fontSize: "14px",
									fontFamily: "poppins",
									children: n(536, "DEX LIQUIDITY")
								}), t && Object(wn.jsx)(yn.a, {
									fontSize: "14px",
									value: t,
									decimals: 0,
									prefix: "$",
									text: "poppins",
									fontWeight: 700
								})]
							}), Object(wn.jsxs)(_n, {
								children: [Object(wn.jsx)(ne, {
									fontSize: "14px",
									fontFamily: "poppins",
									children: n(540, "DISTRIBUTED BANANA/BLOCK")
								}), Object(wn.jsx)(yn.a, {
									fontSize: "14px",
									decimals: 0,
									value: c,
									text: "poppins",
									fontWeight: 700
								})]
							})]
						}), Object(wn.jsx)(ee, {
							href: "https://info.apeswap.finance",
							target: "_blank",
							children: "LEARN MORE"
						})]
					})
				},
				re = t(74),
				ie = function() {
					var n = Object(un.a)(),
						e = Object(sn.c)().account,
						t = Object(An.j)().tvl;
					return e ? Object(wn.jsx)(yn.a, {
						fontSize: "28px",
						differentFontSize: "24px",
						decimals: 0,
						value: t,
						prefix: "$",
						color: "white"
					}) : Object(wn.jsx)(_.db, {
						color: "white",
						style: {
							lineHeight: "30px"
						},
						children: n(298, "Locked")
					})
				},
				ae = Object(J.e)(_.q)(v || (v = Object(X.a)(["\n  align-items: center;\n  justify-content: center;\n  display: flex;\n  flex: 1;\n  background: ", ";\n  max-width: 100%;\n  width: 100%;\n  max-height: 200px;\n  text-align: center;\n\n  ", " {\n    display: block;\n    height: 100%;\n    max-height: 260px;\n  }\n\n  ", " {\n    max-height: 260px;\n  }\n"])), (function(n) {
					return n.theme.isDark ? "#27262c" : "#A16552"
				}), (function(n) {
					return n.theme.mediaQueries.lg
				}), (function(n) {
					return n.theme.mediaQueries.xl
				})),
				ce = Object(J.e)(re.c)(k || (k = Object(X.a)(["\n  width: 100%;\n  height: 100%;\n  max-height: 200px;\n"]))),
				oe = Object(J.e)(_.db)(y || (y = Object(X.a)(["\n  font-size: 12px;\n  line-height: 18px;\n  letter-spacing: 0.05em;\n"]))),
				se = Object(J.e)(_.G)(S || (S = Object(X.a)(["\n  font-size: 12px;\n  line-height: 18px;\n  letter-spacing: 0.05em;\n"]))),
				ue = Object(J.e)(_.F)(z || (z = Object(X.a)(["\n  margin-top: auto;\n  align-items: center;\n"]))),
				pe = J.e.img(A || (A = Object(X.a)(["\n  opacity: 0.1;\n  position: absolute;\n  right: 20px;\n  top: 30px;\n\n  ", " {\n    right: -10px;\n    top: 80px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.lg
				})),
				de = function() {
					var n = Object(un.a)(),
						e = Object(An.u)().toNumber();
					return Object(wn.jsx)(ae, {
						children: Object(wn.jsxs)(ce, {
							to: "/stats",
							children: [Object(wn.jsx)(pe, {
								width: "250px",
								src: "/images/monkey.svg",
								alt: "monkey"
							}), Object(wn.jsxs)(_.r, {
								children: [Object(wn.jsx)(_.G, {
									size: "sm",
									mb: "6px",
									color: "white",
									textAlign: "center",
									children: n(999, "Total Value Locked (TVL)")
								}), e ? Object(wn.jsxs)(wn.Fragment, {
									children: [Object(wn.jsx)(yn.a, {
										fontSize: "28px",
										differentFontSize: "24px",
										decimals: 0,
										value: e,
										prefix: "$",
										color: "white"
									}), Object(wn.jsx)(oe, {
										color: "white",
										children: n(999, "Across all LPs and Pools")
									})]
								}) : Object(wn.jsx)(wn.Fragment, {
									children: Object(wn.jsx)(_.ab, {
										height: 33
									})
								}), Object(wn.jsx)(ie, {}), Object(wn.jsxs)(ue, {
									justifyContent: "flex-end",
									children: [Object(wn.jsx)(se, {
										color: "white",
										size: "sm",
										mt: "10px",
										fontFamily: "poppins",
										children: n(999, "Account TVL")
									}), Object(wn.jsx)(_.d, {
										mt: 10,
										color: "white"
									})]
								})]
							})]
						})
					})
				},
				le = t(1),
				be = Object(J.e)(_.q)(Q || (Q = Object(X.a)(["\n  margin-left: auto;\n  margin-right: auto;\n  height: 100% !important;\n  display: flex !important;\n  flex-direction: column !important;\n  flex: 1;\n  background: ", ";\n  width: 100%;\n  max-height: 160px;\n  text-align: center;\n\n  ", " {\n    max-height: 275px;\n  }\n\n  ", " {\n    max-height: 140px;\n    margin-bottom: 32px;\n  }\n"])), (function(n) {
					return n.theme.isDark ? "#27262c" : "#A16552"
				}), (function(n) {
					return n.theme.mediaQueries.lg
				}), (function(n) {
					return n.theme.mediaQueries.xl
				})),
				fe = Object(J.e)(_.r)(H || (H = Object(X.a)(["\n  width: 100%;\n  height: 100%;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-direction: column;\n"]))),
				je = Object(J.e)(_.F)(C || (C = Object(X.a)(["\n  margin-top: auto;\n  align-items: center;\n  margin-left: auto;\n"]))),
				xe = Object(J.e)(_.G).attrs({
					size: "xl"
				})(N || (N = Object(X.a)(["\n  font-size: 30px;\n  line-height: 45px;\n  text-align: center;\n  letter-spacing: 0.05em;\n\n  ", " {\n    font-size: 22px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.xl
				})),
				he = Object(J.e)(_.G)(T || (T = Object(X.a)(["\n  font-size: 12px;\n  line-height: 18px;\n  letter-spacing: 0.05em;\n"]))),
				me = Object(J.e)(re.c)(F || (F = Object(X.a)(["\n  width: 100%;\n  height: 100%;\n"]))),
				Oe = function() {
					var n = Object(un.a)(),
						e = Object(An.d)(),
						t = Object(An.m)(),
						r = Object(An.n)(),
						i = Object(Y.useRef)(Number.MIN_VALUE),
						a = function() {
							var n = e.filter((function(n) {
								return 0 !== n.pid && "0X" !== n.multiplier
							}));
							return c(n), (100 * i.current).toLocaleString("en-US").slice(0, -1)
						},
						c = Object(Y.useCallback)((function(n) {
							var a, c = new bn.a((null === (a = e.find((function(n) {
								return n.pid === Kn.b
							}))) || void 0 === a ? void 0 : a.tokenPriceVsQuote) || 0);
							n.map((function(n) {
								if (!n.tokenAmount || !n.lpTotalInQuoteToken || !n.lpTotalInQuoteToken) return n;
								var e = Kn.a.times(n.poolWeight),
									a = e.times(Kn.f),
									o = c.times(a).div(n.lpTotalInQuoteToken);
								if (n.quoteTokenSymbol === le.b.BUSD) o = c.times(a).div(n.lpTotalInQuoteToken).times(t);
								else if (n.quoteTokenSymbol === le.b.BANANA) o = a.div(n.lpTotalInQuoteToken);
								else if (n.quoteTokenSymbol === le.b.ETH) o = c.div(r).times(a).div(n.lpTotalInQuoteToken);
								else if (n.dual) {
									var s = n && c.times(e).times(Kn.f).div(n.lpTotalInQuoteToken),
										u = n.tokenPriceVsQuote && new bn.a(n.tokenPriceVsQuote).times(n.dual.rewardPerBlock).times(Kn.f).div(n.lpTotalInQuoteToken);
									o = s && u && s.plus(u)
								}
								return i.current < o.toNumber() && (i.current = o.toNumber()), o
							}))
						}), [t, e, r]);
					return Object(wn.jsx)(be, {
						children: Object(wn.jsxs)(me, {
							to: "/farms",
							children: [Object(wn.jsx)("img", {
								width: "250px",
								style: {
									opacity: .1,
									position: "absolute",
									right: "-80px",
									top: "0px"
								},
								src: "/images/monkey.svg",
								alt: "monkey"
							}), Object(wn.jsxs)(fe, {
								children: [Object(wn.jsx)(_.G, {
									color: "white",
									size: "sm",
									fontSize: "16px",
									mb: "12px",
									children: n(736, "Earn up to APR")
								}), Object(wn.jsx)(xe, {
									color: "white",
									children: a() ? "".concat(a(), "%") : Object(wn.jsx)(_.ab, {
										animation: "pulse",
										variant: "rect",
										height: "44px"
									})
								}), Object(wn.jsxs)(je, {
									justifyContent: "flex-end",
									children: [Object(wn.jsx)(he, {
										color: "white",
										size: "sm",
										mt: "15px",
										fontFamily: "poppins",
										children: "In Farms"
									}), Object(wn.jsx)(_.d, {
										mt: 15,
										color: "white"
									})]
								})]
							})]
						})
					})
				},
				ge = (t(912), t(913)),
				we = function() {
					var n = Object(Y.useState)({
							carouselSlidesData: [],
							loading: !0
						}),
						e = Object(rn.a)(n, 2),
						t = e[0],
						r = e[1];
					return Object(Y.useEffect)((function() {
						(function() {
							var n = Object(tn.a)(en.a.mark((function n() {
								var e;
								return en.a.wrap((function(n) {
									for (;;) switch (n.prev = n.next) {
										case 0:
											return n.prev = 0, n.next = 3, Object(Xn.c)();
										case 3:
											e = n.sent, r({
												carouselSlidesData: e,
												loading: !1
											}), n.next = 10;
											break;
										case 7:
											n.prev = 7, n.t0 = n.catch(0), console.error("Unable to fetch data:", n.t0);
										case 10:
										case "end":
											return n.stop()
									}
								}), n, null, [
									[0, 7]
								])
							})));
							return function() {
								return n.apply(this, arguments)
							}
						})()()
					}), []), t
				},
				ve = Object(J.e)(_.q)(L || (L = Object(X.a)(["\n  text-align: center;\n  width: 100vw !important;\n  margin-left: -16px;\n  border-radius: 0px;\n\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n\n  ", " {\n    width: 100% !important;\n    margin-left: auto;\n    margin-right: auto;\n    border-radius: 32px;\n  }\n\n  ", " {\n    max-width: 100%;\n    margin-left: auto;\n    margin-right: auto;\n    border-radius: 32px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.sm
				}), (function(n) {
					return n.theme.mediaQueries.lg
				})),
				ke = J.e.div(B || (B = Object(X.a)(["\n  width: 80%;\n  margin-left: auto;\n  margin-right: auto;\n\n  ", " {\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.sm
				})),
				ye = J.e.a(I || (I = Object(X.a)(["\n  font-weight: 500;\n  color: #ffb300;\n  display: block;\n  margin-top: 20px;\n  margin-bottom: 20px;\n"]))),
				Se = Object(J.e)(ge.Carousel)(E || (E = Object(X.a)(["\n  .control-dots {\n    position: absolute;\n    bottom: 34px;\n  }\n\n  .carousel .control-dots .dot {\n    opacity: 0.3;\n    width: 14px;\n    height: 14px;\n    background-color: #ffb300;\n    margin-left: 8px;\n    margin-right: 8px;\n    border-radius: 50%;\n    border: 0;\n    outline: none;\n    box-shadow: none;\n  }\n\n  .carousel .slider-wrapper.axis-horizontal .slider .slide {\n    margin-top: auto;\n    margin-bottom: auto;\n  }\n\n  .carousel.carousel-slider {\n    height: 100%;\n  }\n\n  .carousel-root {\n    width: 100%;\n  }\n\n  .slider-wrapper.axis-horizontal {\n    margin-bottom: 20px !important;\n  }\n\n  .carousel .slider-wrapper {\n    ", " {\n      max-width: 450px;\n    }\n    ", " {\n      max-width: 500px;\n    }\n    max-width: 380px;\n    max-height: 260px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.md
				}), (function(n) {
					return n.theme.mediaQueries.lg
				})),
				ze = J.e.div(R || (R = Object(X.a)(["\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  margin-bottom: 24px;\n  width: 100%;\n  ", " {\n    margin-top: 0px;\n    margin-bottom: 12px;\n    position: absolute;\n    bottom: 0px;\n    left: 50%;\n    transform: translateX(-50%);\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.lg
				})),
				Ae = J.e.img(W || (W = Object(X.a)(["\n  position: absolute;\n  right: 11px;\n  top: 50%;\n  transform: translateY(-50%);\n  cursor: pointer;\n  padding: 80px 15px;\n  z-index: 100;\n\n  ", " {\n    right: 22px;\n    padding: 80px 10px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.sm
				})),
				Qe = J.e.img(D || (D = Object(X.a)(["\n  position: absolute;\n  left: 11px;\n  top: 50%;\n  transform: translateY(-50%);\n  cursor: pointer;\n  padding: 80px 15px;\n  z-index: 100;\n\n  ", " {\n    left: 22px;\n    padding: 80px 10px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.sm
				})),
				He = J.e.div(P || (P = Object(X.a)(["\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n  width: 100%;\n  margin-top: 30px;\n  ", " {\n    margin-bottom: 60px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.lg
				})),
				Ce = J.e.div(q || (q = Object(X.a)(["\n  background: url(", ");\n  background-repeat: no-repeat;\n  background-size: contain;\n  margin-top: 12px;\n  height: 244px;\n"])), (function(n) {
					return n.image
				})),
				Ne = function() {
					var n = Object(Y.useState)(0),
						e = Object(rn.a)(n, 2),
						t = e[0],
						r = e[1],
						i = we(),
						a = i.carouselSlidesData,
						c = i.loading;
					return Object(wn.jsxs)(ve, {
						children: [Object(wn.jsx)(Te, {
							onClick: function() {
								return function() {
									var n = t;
									n >= 1 ? --n : n = a.length - 1, r(n)
								}()
							}
						}), Object(wn.jsx)(ze, {
							children: c ? Object(wn.jsx)(He, {
								className: "something",
								children: Object(wn.jsx)(_.bb, {})
							}) : Object(wn.jsx)(Se, {
								infiniteLoop: !0,
								autoPlay: !0,
								selectedItem: t,
								showStatus: !1,
								showArrows: !1,
								children: a.map((function(n) {
									return Object(wn.jsx)(Le, {
										slide: n
									})
								}))
							})
						}), Object(wn.jsx)(Fe, {
							onClick: function() {
								return function() {
									var n = a.length - 1,
										e = t;
									t < n ? ++e : e = 0, r(e)
								}()
							}
						})]
					})
				},
				Te = function(n) {
					var e = n.onClick;
					return Object(wn.jsx)(Qe, {
						width: "45px",
						role: "presentation",
						src: "/images/leftArrow.svg",
						alt: "leftArrow",
						onClick: e
					})
				},
				Fe = function(n) {
					var e = n.onClick;
					return Object(wn.jsx)(Ae, {
						width: "45px",
						role: "presentation",
						src: "/images/rightArrow.svg",
						alt: "rightArrow",
						onClick: e
					})
				},
				Le = function(n) {
					var e, t = n.slide;
					return Object(wn.jsx)("a", {
						href: "".concat(t.pageLink),
						children: 0 !== t.image.length ? Object(wn.jsx)(Ce, {
							image: (e = t.image[0], "".concat(Xn.b).concat(e.url)),
							className: "container-image"
						}) : Object(wn.jsxs)(_.r, {
							children: [Object(wn.jsx)(_.G, {
								size: "lg",
								mb: "24px",
								children: "".concat(t.header)
							}), Object(wn.jsxs)(ke, {
								children: [Object(wn.jsx)(_.db, {
									color: "textSubtle",
									fontFamily: "poppins",
									mb: "8px",
									children: "".concat(t.text)
								}), Object(wn.jsx)(_.db, {
									color: "textSubtle",
									fontFamily: "poppins",
									children: "".concat(t.text2)
								}), Object(wn.jsx)(_.db, {
									color: "textSubtle",
									children: Object(wn.jsx)(ye, {
										href: "".concat(t.pageLink),
										children: "".concat(t.link)
									})
								})]
							})]
						})
					})
				},
				Be = Object(J.e)(_.q)(U || (U = Object(X.a)(["\n  text-align: center;\n  height: 170px;\n  width: 100%;\n  margin-bottom: 38px;\n  overflow: visible;\n  margin-top: 30px;\n\n  ", " {\n    margin-bottom: 64px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.xs
				})),
				Ie = Object(J.e)(_.F)(V || (V = Object(X.a)(["\n  text-align: center;\n"]))),
				Ee = Object(J.e)(_.db)(G || (G = Object(X.a)(["\n  font-weight: 400;\n"]))),
				Re = J.e.img(M || (M = Object(X.a)(["\n  margin-top: -60px;\n  width: 300px;\n  height: 100%;\n  max-height: 220px;\n\n  ", " {\n    margin-top: -75px;\n    max-height: 240px;\n  }\n\n  ", " {\n    margin-top: -75px;\n    max-height: 250px;\n  }\n\n  ", " {\n    margin-top: -85px;\n    max-height: 285px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.xs
				}), (function(n) {
					return n.theme.mediaQueries.md
				}), (function(n) {
					return n.theme.mediaQueries.lg
				})),
				We = function() {
					var n = Object(un.a)();
					return Object(wn.jsxs)(Ie, {
						flexDirection: "column",
						alignItems: "center",
						children: [Object(wn.jsx)(Be, {
							children: Object(wn.jsx)(_.r, {
								children: Object(wn.jsx)(Re, {
									src: "/images/ape-banana-frenzy-summer.svg",
									alt: "banana frenzy"
								})
							})
						}), Object(wn.jsx)(_.G, {
							as: "h1",
							size: "lg",
							mb: "6px",
							color: "contrast",
							children: n(576, "Welcome all Apes!")
						}), Object(wn.jsx)(Ee, {
							color: "textSubtle",
							fontFamily: "poppins",
							children: n(578, "Why be a human, when you can be an ape?")
						})]
					})
				},
				De = Object(J.e)(_.j)($ || ($ = Object(X.a)(["\n  align-items: stretch;\n  justify-content: stretch;\n  margin-bottom: 32px;\n\n  & > div {\n    grid-column: span 6;\n    width: 100%;\n  }\n\n  ", " {\n    & > div {\n      grid-column: span 8;\n      width: 100%;\n    }\n  }\n\n  ", " {\n    & > div {\n      grid-column: span 12;\n      width: 100%;\n    }\n  }\n\n  ", " {\n    & > div {\n      grid-column: span 7;\n    }\n\n    & > div:first-child {\n      grid-column: ", ";\n    }\n\n    & > div:last-child {\n      grid-column: ", ";\n    }\n  }\n\n  ", " {\n    & > div {\n      grid-column: span 4;\n    }\n\n    & > div:first-child {\n      grid-column: ", ";\n    }\n\n    & > div:last-child {\n      grid-column: ", ";\n    }\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.sm
				}), (function(n) {
					return n.theme.mediaQueries.md
				}), (function(n) {
					return n.theme.mediaQueries.lg
				}), (function(n) {
					var e = n.spanFirst;
					return e ? "span ".concat(e) : "span 5"
				}), (function(n) {
					var e = n.spanLast;
					return 7 === e ? "span ".concat(e) : "span 12"
				}), (function(n) {
					return n.theme.mediaQueries.xl
				}), (function(n) {
					var e = n.spanFirst;
					return e ? "span ".concat(e) : "span 5"
				}), (function(n) {
					var e = n.spanLast;
					return e ? "span ".concat(e) : "span 6"
				})),
				Pe = Object(J.e)(De)(K || (K = Object(X.a)(["\n  ", " {\n    display: grid;\n\n    & > div:first-child {\n      grid-column: span 5;\n    }\n\n    & > div:last-child {\n      grid-column: span 7 !important;\n    }\n  }\n\n  ", " {\n    display: flex;\n    flex-direction: column;\n    grid-gap: 0px;\n    margin-bottom: 0px;\n  }\n"])), (function(n) {
					return n.theme.mediaQueries.lg
				}), (function(n) {
					return n.theme.mediaQueries.xl
				})),
				qe = function() {
					return Object(wn.jsxs)(Z.a, {
						width: "1200px",
						children: [Object(wn.jsxs)(De, {
							spanLast: 7,
							children: [Object(wn.jsx)(We, {}), Object(wn.jsx)(Ne, {})]
						}), Object(wn.jsxs)(De, {
							spanLast: 3,
							children: [Object(wn.jsx)($n, {}), Object(wn.jsx)(te, {}), Object(wn.jsxs)(Pe, {
								children: [Object(wn.jsx)(Oe, {}), Object(wn.jsx)(de, {})]
							})]
						})]
					})
				}
		},
		784: function(n, e, t) {
			"use strict";
			t.d(e, "a", (function() {
				return a
			})), t.d(e, "b", (function() {
				return c
			}));
			var r = t(12),
				i = t.n(r),
				a = function(n) {
					var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 18,
						t = new i.a(n).dividedBy(new i.a(10).pow(e));
					return t.toNumber()
				},
				c = function(n) {
					var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 18;
					return n.dividedBy(new i.a(10).pow(e)).toFixed()
				}
		},
		791: function(n, e, t) {
			"use strict";
			var r, i = t(58),
				a = t(0),
				c = t(4),
				o = t(810),
				s = t(23),
				u = t(7);
			e.a = function(n) {
				var e = n.value,
					t = n.decimals,
					p = n.fontSize,
					d = void 0 === p ? "px" : p,
					l = n.prefix,
					b = n.color,
					f = n.text,
					j = n.fontWeight,
					x = n.differentFontSize,
					h = Object(o.useCountUp)({
						start: 0,
						end: e,
						duration: 1,
						separator: ",",
						decimals: void 0 !== t ? t : e < 0 ? 4 : e > 1e5 ? 0 : 3
					}),
					m = h.countUp,
					O = h.update,
					g = Object(c.e)(s.db)(r || (r = Object(i.a)(["\n    font-weight: ", ";\n\n    ", " {\n      font-size: ", ";\n    }\n  "])), j || 400, (function(n) {
						return n.theme.mediaQueries.xl
					}), x || d),
					w = Object(a.useRef)(O);
				return Object(a.useEffect)((function() {
					w.current(e)
				}), [e, w]), Object(u.jsxs)(g, {
					bold: !0,
					fontSize: d,
					color: b,
					fontFamily: f,
					children: [l, " ", m]
				})
			}
		},
		792: function(n, e, t) {
			"use strict";
			e.a = {
				rewardBanana: {
					fakingRequest: !1,
					angle: 90,
					decay: .91,
					spread: 100,
					startVelocity: 20,
					elementCount: 15,
					elementSize: 20,
					lifetime: 200,
					zIndex: 10,
					springAnimation: !0,
					rewardPunish: "reward",
					type: "emoji",
					emoji: ["\ud83c\udf4c", "\ud83d\ude48", "\ud83c\udf4c", "\ud83d\ude49", "\ud83c\udf4c", "\ud83d\ude4a"]
				},
				removed: {
					fakingRequest: !1,
					angle: 90,
					decay: .91,
					spread: 100,
					startVelocity: 20,
					elementCount: 15,
					elementSize: 20,
					lifetime: 200,
					zIndex: 10,
					springAnimation: !0,
					rewardPunish: "reward",
					type: "emoji",
					emoji: ["\ud83d\udcb0", "\ud83e\udd11", "\ud83d\udcb0", "\ud83d\ude48"]
				},
				error: {
					fakingRequest: !1,
					angle: 90,
					decay: .95,
					spread: 120,
					startVelocity: 10,
					elementCount: 10,
					elementSize: 20,
					lifetime: 200,
					zIndex: 10,
					springAnimation: !0,
					rewardPunish: "reward",
					type: "emoji",
					emoji: ["\ud83d\udc94", "\ud83d\udc94", "\ud83d\udc94", "\ud83d\ude31", "\ud83d\udc7d", "\ud83d\ude48"]
				}
			}
		},
		793: function(n, e, t) {
			"use strict";
			var r = t(2),
				i = t.n(r),
				a = t(9),
				c = t(0);
			e.a = function(n, e) {
				return Object(c.useCallback)(Object(a.a)(i.a.mark((function t() {
					var r, a = arguments;
					return i.a.wrap((function(t) {
						for (;;) switch (t.prev = t.next) {
							case 0:
								return t.next = 2, e.apply(void 0, a);
							case 2:
								null === (r = n.current) || void 0 === r || r.rewardMe();
							case 3:
							case "end":
								return t.stop()
						}
					}), t)
				}))), [e, n])
			}
		},
		799: function(n, e, t) {
			"use strict";
			t.d(e, "a", (function() {
				return u
			})), t.d(e, "i", (function() {
				return p
			})), t.d(e, "d", (function() {
				return d
			})), t.d(e, "e", (function() {
				return l
			})), t.d(e, "j", (function() {
				return b
			})), t.d(e, "f", (function() {
				return f
			})), t.d(e, "c", (function() {
				return j
			})), t.d(e, "b", (function() {
				return x
			})), t.d(e, "g", (function() {
				return h
			})), t.d(e, "h", (function() {
				return m
			}));
			var r = t(2),
				i = t.n(r),
				a = t(9),
				c = t(12),
				o = t.n(c),
				s = t(807),
				u = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t, r) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									return n.abrupt("return", e.methods.approve(t.options.address, s.a.constants.MaxUint256).send({
										from: r
									}));
								case 1:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t, r) {
						return n.apply(this, arguments)
					}
				}(),
				p = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t, r, a) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									if (0 !== t) {
										n.next = 2;
										break
									}
									return n.abrupt("return", e.methods.enterStaking(new o.a(r).times(new o.a(10).pow(18)).toString()).send({
										from: a
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 2:
									return n.abrupt("return", e.methods.deposit(t, new o.a(r).times(new o.a(10).pow(18)).toString()).send({
										from: a
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 3:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t, r, i) {
						return n.apply(this, arguments)
					}
				}(),
				d = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t, r) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									return n.abrupt("return", e.methods.deposit(new o.a(t).times(new o.a(10).pow(18)).toString()).send({
										from: r
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 1:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t, r) {
						return n.apply(this, arguments)
					}
				}(),
				l = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t, r) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									return n.abrupt("return", e.methods.deposit().send({
										from: r,
										value: new o.a(t).times(new o.a(10).pow(18)).toString()
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 1:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t, r) {
						return n.apply(this, arguments)
					}
				}(),
				b = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t, r, a) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									if (0 !== t) {
										n.next = 2;
										break
									}
									return n.abrupt("return", e.methods.leaveStaking(new o.a(r).times(new o.a(10).pow(18)).toString()).send({
										from: a
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 2:
									return n.abrupt("return", e.methods.withdraw(t, new o.a(r).times(new o.a(10).pow(18)).toString()).send({
										from: a
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 3:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t, r, i) {
						return n.apply(this, arguments)
					}
				}(),
				f = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t, r) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									if ("0x3B9B74f48E89Ebd8b45a53444327013a2308A9BC" !== e.options.address) {
										n.next = 2;
										break
									}
									return n.abrupt("return", e.methods.emergencyWithdraw().send({
										from: r
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 2:
									if ("0xBb2B66a2c7C2fFFB06EA60BeaD69741b3f5BF831" !== e.options.address) {
										n.next = 4;
										break
									}
									return n.abrupt("return", e.methods.emergencyWithdraw().send({
										from: r
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 4:
									return n.abrupt("return", e.methods.withdraw(new o.a(t).times(new o.a(10).pow(18)).toString()).send({
										from: r
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 5:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t, r) {
						return n.apply(this, arguments)
					}
				}(),
				j = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t, r) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									return n.abrupt("return", e.methods.emergencyWithdraw().send({
										from: r
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 1:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t, r) {
						return n.apply(this, arguments)
					}
				}(),
				x = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t, r) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									if (0 !== t) {
										n.next = 2;
										break
									}
									return n.abrupt("return", e.methods.leaveStaking("0").send({
										from: r
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 2:
									return n.abrupt("return", e.methods.deposit(t, "0").send({
										from: r
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 3:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t, r) {
						return n.apply(this, arguments)
					}
				}(),
				h = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									return n.abrupt("return", e.methods.deposit("0").send({
										from: t
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 1:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t) {
						return n.apply(this, arguments)
					}
				}(),
				m = function() {
					var n = Object(a.a)(i.a.mark((function n(e, t) {
						return i.a.wrap((function(n) {
							for (;;) switch (n.prev = n.next) {
								case 0:
									return n.abrupt("return", e.methods.deposit().send({
										from: t,
										value: new o.a(0)
									}).on("transactionHash", (function(n) {
										return n.transactionHash
									})));
								case 1:
								case "end":
									return n.stop()
							}
						}), n)
					})));
					return function(e, t) {
						return n.apply(this, arguments)
					}
				}()
		},
		809: function(n, e, t) {
			"use strict";
			t.d(e, "b", (function() {
				return b
			})), t.d(e, "a", (function() {
				return f
			})), t.d(e, "c", (function() {
				return j
			}));
			var r = t(77),
				i = t(2),
				a = t.n(i),
				c = t(9),
				o = t(0),
				s = t(43),
				u = t(22),
				p = t(78),
				d = t(799),
				l = t(785),
				b = function(n) {
					var e = Object(u.b)(),
						t = Object(s.c)().account,
						r = Object(l.g)();
					return {
						onReward: Object(o.useCallback)(Object(c.a)(a.a.mark((function i() {
							var c;
							return a.a.wrap((function(i) {
								for (;;) switch (i.prev = i.next) {
									case 0:
										return i.next = 2, Object(d.b)(r, n, t);
									case 2:
										return c = i.sent, e(Object(p.b)(t)), i.abrupt("return", c);
									case 5:
									case "end":
										return i.stop()
								}
							}), i)
						}))), [t, e, n, r])
					}
				},
				f = function(n) {
					var e = Object(s.c)().account,
						t = Object(l.g)();
					return {
						onReward: Object(o.useCallback)(Object(c.a)(a.a.mark((function i() {
							var c;
							return a.a.wrap((function(i) {
								for (;;) switch (i.prev = i.next) {
									case 0:
										return c = n.reduce((function(n, i) {
											return [].concat(Object(r.a)(n), [Object(d.b)(t, i, e)])
										}), []), i.abrupt("return", Promise.all(c));
									case 2:
									case "end":
										return i.stop()
								}
							}), i)
						}))), [e, n, t])
					}
				},
				j = function(n) {
					var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
						t = Object(u.b)(),
						r = Object(s.c)(),
						i = r.account,
						b = Object(l.l)(n),
						f = Object(l.g)(),
						j = Object(o.useCallback)(Object(c.a)(a.a.mark((function r() {
							return a.a.wrap((function(r) {
								for (;;) switch (r.prev = r.next) {
									case 0:
										if (0 !== n) {
											r.next = 5;
											break
										}
										return r.next = 3, Object(d.b)(f, 0, i);
									case 3:
										r.next = 12;
										break;
									case 5:
										if (!e) {
											r.next = 10;
											break
										}
										return r.next = 8, Object(d.h)(b, i);
									case 8:
										r.next = 12;
										break;
									case 10:
										return r.next = 12, Object(d.g)(b, i);
									case 12:
										t(Object(p.j)(n, i)), t(Object(p.i)(n, i));
									case 14:
									case "end":
										return r.stop()
								}
							}), r)
						}))), [i, t, e, f, b, n]);
					return {
						onReward: j
					}
				}
		}
	}
]);
//# sourceMappingURL=16.80510610.chunk.js.map